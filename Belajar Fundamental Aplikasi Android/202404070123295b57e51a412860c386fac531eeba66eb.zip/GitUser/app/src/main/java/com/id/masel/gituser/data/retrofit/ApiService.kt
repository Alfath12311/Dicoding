package com.id.masel.gituser.data.retrofit

import com.id.masel.gituser.data.response.DetailUser
import com.id.masel.gituser.data.response.Users
import com.id.masel.gituser.data.response.UserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUsers(
        @Query("q") query: String
    ): Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUserDetail(
        @Path("username") username: String
    ): Call<DetailUser>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getUserFollowers(
        @Path("username") username: String
    ): Call<ArrayList<Users>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getUserFollowing(
        @Path("username") username: String
    ): Call<ArrayList<Users>>
}