package com.id.masel.gituser.ui.detailact

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.id.masel.gituser.data.response.Users
import com.id.masel.gituser.data.retrofit.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersViewModel: ViewModel() {
    //Followers
    val listFollower = MutableLiveData<ArrayList<Users>>()
    fun setListFollowers(username: String){
        ApiClient.apiInstance
            .getUserFollowers(username)
            .enqueue(object: Callback<ArrayList<Users>>{
                override fun onResponse(p0: Call<ArrayList<Users>>, p1: Response<ArrayList<Users>>) {
                    if(p1.isSuccessful){
                        listFollower.postValue(p1.body())
                    }
                }
                override fun onFailure(p0: Call<ArrayList<Users>>, p1: Throwable) {
                    p1.message?.let { Log.d("Failure", it) }
                }

            })
    }
    fun getListFollowers(): LiveData<ArrayList<Users>>{
        return listFollower
    }

    //Following
    val listFollowing = MutableLiveData<ArrayList<Users>>()
    fun setListFollowing(username: String){
        ApiClient.apiInstance
            .getUserFollowing(username)
            .enqueue(object: Callback<ArrayList<Users>>{
                override fun onResponse(p0: Call<ArrayList<Users>>, p1: Response<ArrayList<Users>>) {
                    if(p1.isSuccessful){
                        listFollowing.postValue(p1.body())
                    }
                }
                override fun onFailure(p0: Call<ArrayList<Users>>, p1: Throwable) {
                    p1.message?.let { Log.d("Failure", it) }
                }
            })
    }
    fun getListFollowing(): LiveData<ArrayList<Users>>{
        return listFollowing
    }
}