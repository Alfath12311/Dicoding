package com.id.masel.gituser.ui.favoriteact

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.id.masel.gituser.data.local.FavoriteDao
import com.id.masel.gituser.data.local.FavoriteDatabase
import com.id.masel.gituser.data.local.FavoriteUser

class FavoriteViewModel(application: Application): AndroidViewModel(application){
    private val favoriteDao: FavoriteDao?
    private val favoriteDatabase: FavoriteDatabase?

    init {
        favoriteDatabase = FavoriteDatabase.getDatabase(application)
        favoriteDao = favoriteDatabase?.favoriteUserDao()
    }

    fun getFavoriteUser(): LiveData<List<FavoriteUser>>?{
        return favoriteDao?.getAllFavorite()
    }
}