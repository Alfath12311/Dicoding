package com.id.masel.gituser.ui.detailact


import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import id.masel.gituser.R
import id.masel.gituser.databinding.ActivityDetailUserBinding
import com.id.masel.gituser.ui.favoriteact.FavoriteActivity
import com.id.masel.gituser.ui.mainact.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailUserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_ID = "extra_id"
        const val EXTRA_AVATAR = "extra_avatar"
    }

    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var viewModel: DetailUserViewModel

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(true)

        val id = intent.getIntExtra(EXTRA_ID, 0)
        val username = intent.getStringExtra(EXTRA_USERNAME)
        val avatarUrl = intent.getStringExtra(EXTRA_AVATAR)

        val bundle = Bundle()
        bundle.putString(EXTRA_USERNAME, username)

        viewModel = ViewModelProvider(this)[DetailUserViewModel::class.java]
        viewModel.setUserDetail(username!!)
        viewModel.getUserDetail().observe(this) {
            if (it != null) {
                binding.apply {
                    tvUsername.text = it.login
                    tvName.text = it.name
                    tvFollowers.text = "${it.followers} Followers"
                    tvFollowing.text = "${it.following} Following"

                    Glide.with(this@DetailUserActivity)
                        .load(it.avatar_url)
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .circleCrop()
                        .into(ivProfile)

                    showLoading(false)
                }
            }
        }
        var isChecked = false
        val fabFavorite = binding.fabFavorite
        CoroutineScope(Dispatchers.IO).launch {
            val count = viewModel.checkFavoriteUser(id)
            withContext(Dispatchers.Main) {
                if (count != null) {
                    if (count > 0) {
                        fabFavorite.setImageDrawable(
                            ContextCompat.getDrawable(
                                applicationContext,
                                R.drawable.favorite_red
                            )
                        )
                        isChecked = true
                    }
                }
            }
        }
        fabFavorite.setOnClickListener {
            isChecked = !isChecked
            if (isChecked) {
                viewModel.addToFavorite(id, username, avatarUrl!!)
                fabFavorite.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext,
                        R.drawable.favorite_red
                    )
                )
                Toast.makeText(this@DetailUserActivity, "Berhasi Menambahkan", Toast.LENGTH_SHORT)
                    .show()
            } else {
                viewModel.removeFromFavorite(id)
                fabFavorite.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext,
                        R.drawable.not_favorite_red
                    )
                )
                Toast.makeText(this@DetailUserActivity, "Berhasi Menghapus", Toast.LENGTH_SHORT)
                    .show()
            }
            binding.fabFavorite.isActivated = isChecked
        }

        val sectionPagerAdapter = SectionPagerAdapter(this, supportFragmentManager, bundle)
        @Suppress("DEPRECATION")
        Handler().postDelayed({
            binding.apply {
                viewPager.adapter = sectionPagerAdapter
                tabs.setupWithViewPager(viewPager)
            }
        }, 500)

        binding.apply {
            topAppBar.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.button_favorite -> {
                        goToFavorite()
                        true
                    }

                    R.id.button_home -> {
                        goToHome()
                        true
                    }

                    else -> {
                        false
                    }
                }
            }
        }
    }

    private fun goToFavorite() {
        Intent(this, FavoriteActivity::class.java).also {
            startActivity(it)
        }
    }

    private fun goToHome() {
        val backToHome = Intent(this, MainActivity::class.java)
        backToHome.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(backToHome)
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}