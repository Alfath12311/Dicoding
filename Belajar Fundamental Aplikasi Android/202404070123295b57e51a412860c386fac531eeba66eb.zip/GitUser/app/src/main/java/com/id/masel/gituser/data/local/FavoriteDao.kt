package com.id.masel.gituser.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FavoriteDao {
    @Insert
    suspend fun addToFavorite(favoriteUser: FavoriteUser)

    @Query("SELECT * FROM favorite_user")
    fun getAllFavorite(): LiveData<List<FavoriteUser>>

    @Query("SELECT COUNT(*) FROM favorite_user WHERE favorite_user.id = :id")
    suspend fun checkFavoriteUser(id: Int): Int

    @Query("SELECT COUNT(*) FROM favorite_user WHERE favorite_user.id = :id")
    suspend fun check(id: Int): Int

    @Query("DELETE FROM favorite_user WHERE favorite_user.id = :id")
    suspend fun deleteFavoriteUser(id: Int): Int
}