package com.id.masel.gituser.ui.mainact

class ListUserBinding {

}