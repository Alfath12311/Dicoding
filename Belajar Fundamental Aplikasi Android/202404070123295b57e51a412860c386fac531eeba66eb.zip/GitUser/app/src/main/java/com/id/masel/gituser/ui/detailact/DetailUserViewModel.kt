package com.id.masel.gituser.ui.detailact

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.id.masel.gituser.data.local.FavoriteDao
import com.id.masel.gituser.data.local.FavoriteDatabase
import com.id.masel.gituser.data.local.FavoriteUser
import com.id.masel.gituser.data.response.DetailUser
import com.id.masel.gituser.data.retrofit.ApiClient
import com.id.masel.gituser.data.retrofit.ApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Response

class DetailUserViewModel(application: Application) : AndroidViewModel(application) {
    val user = MutableLiveData<DetailUser>()

    private val favoriteDao: FavoriteDao?
    private val favoriteDatabase: FavoriteDatabase?

    init {
        favoriteDatabase = FavoriteDatabase.getDatabase(application)
        favoriteDao = favoriteDatabase?.favoriteUserDao()
    }

    fun setUserDetail(username: String) {
        ApiClient.apiInstance
            .getUserDetail(username)
            .enqueue(object : retrofit2.Callback<DetailUser> {
                override fun onResponse(p0: Call<DetailUser>, p1: Response<DetailUser>) {
                    if (p1.isSuccessful) {
                        user.postValue(p1.body())
                    }
                }

                override fun onFailure(p0: Call<DetailUser>, p1: Throwable) {
                    p1.message?.let { Log.d("Failure", it) }
                }

            })
    }

    fun getUserDetail(): LiveData<DetailUser> {
        return user
    }

    fun addToFavorite(id: Int, username: String, avatarUrl: String) {
        CoroutineScope(Dispatchers.IO).launch {
            var favUser = FavoriteUser(
                id,
                username,
                avatarUrl
            )
            favoriteDao?.addToFavorite(favUser)
        }
    }

    fun removeFromFavorite(id: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            favoriteDao?.deleteFavoriteUser(id)
        }
    }

    suspend fun checkFavoriteUser(id: Int) = favoriteDao?.checkFavoriteUser(id)
}