package com.id.masel.gituser.data.response

data class UserResponse(
    val items: ArrayList<Users>
)