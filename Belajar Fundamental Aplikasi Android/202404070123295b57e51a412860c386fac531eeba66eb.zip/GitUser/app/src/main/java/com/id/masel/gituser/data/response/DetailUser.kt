package com.id.masel.gituser.data.response

data class DetailUser(
        val login: String,
        val id: Int,
        val avatar_url: String,
        val name: String,
        val followers_url: String,
        val followers: Int,
        val following_url: String,
        val following: Int
)
