package com.id.masel.mystoryapp.activity.splashscreen

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.id.masel.mystoryapp.data.Repository

class SplashscreenViewModel(private val repository: Repository) : ViewModel() {
    fun getUser(): LiveData<String?> = repository.getUser()
}