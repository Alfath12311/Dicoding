@file:Suppress("DEPRECATION")

package com.id.masel.mystoryapp.activity.add

import android.Manifest
import android.app.ProgressDialog
import android.content.ContentValues.TAG
import android.content.Intent
import android.content.Intent.ACTION_GET_CONTENT
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.CompoundButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.id.masel.mystoryapp.R
import com.id.masel.mystoryapp.data.Resource
import com.id.masel.mystoryapp.data.model.UploadResponse
import com.id.masel.mystoryapp.databinding.ActivityAddStoryBinding
import com.id.masel.mystoryapp.utility.Constanta.EXTRA_TOKEN
import com.id.masel.mystoryapp.utility.ViewModelFactory
import com.id.masel.mystoryapp.utility.ViewStateCallback
import com.id.masel.mystoryapp.utility.getAddressName
import com.id.masel.mystoryapp.utility.reduceFileSize
import com.id.masel.mystoryapp.utility.rotateFile
import com.id.masel.mystoryapp.utility.uriToFile
import com.id.masel.mystoryapp.activity.MainActivity
import com.id.masel.mystoryapp.activity.camera.CameraActivity
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class AddStoryActivity : AppCompatActivity(), ViewStateCallback<UploadResponse> {

    private lateinit var addStoryBinding: ActivityAddStoryBinding
    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val addStoryViewModel: AddStoryViewModel by viewModels {
        factory
    }

    private var myFile: File? = null
    private lateinit var token: String

    private lateinit var progressDialog: ProgressDialog

    private var location: Location? = null
    private var locLatitude: RequestBody? = null
    private var locLongitude: RequestBody? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addStoryBinding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(addStoryBinding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        getMyLocation()

        if (!allPermissionGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            elevation = 0f
        }

        addStoryViewModel.getUser().observe(this) {
            if (it != null)
                token = it
        }

        addStoryBinding.btnCamera.setOnClickListener { startCameraX() }
        addStoryBinding.btnGallery.setOnClickListener { startGallery() }

        addStoryBinding.scLocation.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
            if (isChecked) {
                addStoryBinding.scLocation.text = location?.let {
                    getAddressName(this@AddStoryActivity, it.latitude, location!!.longitude)
                }
                locLatitude = location?.latitude?.toString()?.toRequestBody("text/plain".toMediaType())!!
                locLongitude = location?.longitude?.toString()?.toRequestBody("text/plain".toMediaType())!!
            } else {
                addStoryBinding.scLocation.text = getString(R.string.save_my_current_location)
            }
        }

        addStoryBinding.btnDetailSubmit.setOnClickListener {
            uploadStory()
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }

    private fun getMyLocation() {
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation.addOnSuccessListener {
                if (it != null) {
                    this.location = it
                } else {
                    Toast.makeText(this, getString(R.string.try_again), Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun uploadStory() {
        val desc = addStoryBinding.etDesc.text.toString()
        val description = desc.toRequestBody("text/plain".toMediaType())

        if (desc.isEmpty()) {
            Toast.makeText(this, getString(R.string.required_desc), Toast.LENGTH_SHORT).show()
        } else {
            if (myFile == null) {
                Toast.makeText(this, getString(R.string.required_pic), Toast.LENGTH_SHORT).show()
            } else {
                val uploadImage = reduceFileSize(myFile as File)
                val requestImage = uploadImage.asRequestBody("image/jpeg".toMediaTypeOrNull())
                val reqImageFile = MultipartBody.Part.createFormData("photo", uploadImage.name, requestImage)

                addStoryViewModel.addStory(token, reqImageFile, description, locLatitude, locLongitude).observe(this) {
                    if (it != null) {
                        when (it) {
                            is Resource.Success -> it.data?.let { it1 -> onSuccess(it1) }
                            is Resource.Error -> onError(it.message)
                            is Resource.Loading -> onLoading()
                        }
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionGranted()) {
                Toast.makeText(this, getString(R.string.no_permission), Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

    private fun allPermissionGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launcherIntentGallery.launch(chooser)
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg = result.data?.data as Uri
            selectedImg.let { uri ->
                val getFile = uriToFile(uri, this@AddStoryActivity)
                myFile = getFile
                addStoryBinding.ivImgDesc.setImageURI(uri)
            }
        }
    }

    private fun startCameraX() {
        val intent = Intent(this, CameraActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            myFile = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                it.data?.getSerializableExtra("picture", File::class.java)
            } else {
                it.data?.getSerializableExtra("picture")
            } as? File)!!

            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean

            myFile.let { file ->
                if (file != null) {
                    rotateFile(file, isBackCamera)
                }
                intent.putExtra(EXTRA_RESULT, myFile)
                if (file != null) {
                    addStoryBinding.ivImgDesc.setImageBitmap(BitmapFactory.decodeFile(file.path))
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return super.onSupportNavigateUp()
    }

    override fun onSuccess(data: UploadResponse) {
        Log.e("ADD STORY Success", "onSuccess: Add Story $data")
        Toast.makeText(this, getString(R.string.story_uploaded), Toast.LENGTH_SHORT).show()


        val latitude = location?.latitude ?: 0.0
        val longitude = location?.longitude ?: 0.0
        val name = "User Name"
        val description = addStoryBinding.etDesc.text.toString()

        val broadcastIntent = Intent("STORY_UPLOADED")
        broadcastIntent.putExtra("latitude", latitude)
        broadcastIntent.putExtra("longitude", longitude)
        broadcastIntent.putExtra("name", name)
        broadcastIntent.putExtra("description", description)
        LocalBroadcastManager.getInstance(this).sendBroadcast(broadcastIntent)


        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra(EXTRA_TOKEN, token)
        startActivity(intent)
        finish()
    }




    override fun onLoading() {
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please Wait")
        progressDialog.setMessage("Loading ...")
        progressDialog.setCancelable(true)
        progressDialog.show()
    }

    override fun onError(error: String?) {
        Log.e(TAG, "onFailed Add: $error")
        Toast.makeText(this, getString(R.string.try_again), Toast.LENGTH_SHORT)
            .show()
    }

    companion object {
        const val CAMERA_X_RESULT = 200

        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10

        const val EXTRA_RESULT = "EXTRA_RESULT"
    }
}
