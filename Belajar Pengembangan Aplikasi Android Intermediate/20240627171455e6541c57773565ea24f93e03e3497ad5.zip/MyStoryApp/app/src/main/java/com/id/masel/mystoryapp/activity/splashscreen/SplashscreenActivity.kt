package com.id.masel.mystoryapp.activity.splashscreen

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.id.masel.mystoryapp.databinding.ActivitySplashscreenBinding
import com.id.masel.mystoryapp.utility.Constanta.EXTRA_TOKEN
import com.id.masel.mystoryapp.utility.Constanta.TIME_SPLASH
import com.id.masel.mystoryapp.utility.ViewModelFactory
import com.id.masel.mystoryapp.activity.MainActivity
import com.id.masel.mystoryapp.activity.login.LoginActivity

@SuppressLint("CustomSplashScreen")
class SplashscreenActivity : AppCompatActivity() {

    private lateinit var splashscreenBinding: ActivitySplashscreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        splashscreenBinding = ActivitySplashscreenBinding.inflate(layoutInflater)
        setContentView(splashscreenBinding.root)

        supportActionBar?.hide()

        val handler = Handler(mainLooper)

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
        val splashscreenViewModel: SplashscreenViewModel by viewModels {
            factory
        }
        handler.postDelayed({
            splashscreenViewModel.getUser().observe(this) {
                if (it.isNullOrEmpty()) {
                    Log.e(TAG, "login")
                    startActivity(Intent(this@SplashscreenActivity, LoginActivity::class.java))
                    finish()
                } else {
                    Log.e(TAG, "udah login $it")
                    val intent = Intent(this@SplashscreenActivity, MainActivity::class.java)
                    intent.putExtra(EXTRA_TOKEN, it)
                    startActivity(intent)
                    finish()
                }
            }
        }, TIME_SPLASH)
    }
}