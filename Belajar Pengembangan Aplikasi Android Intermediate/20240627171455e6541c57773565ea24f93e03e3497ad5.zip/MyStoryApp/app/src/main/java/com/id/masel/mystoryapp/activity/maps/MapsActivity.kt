package com.id.masel.mystoryapp.activity.maps

import android.Manifest
import android.content.ContentValues.TAG
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.id.masel.mystoryapp.R
import com.id.masel.mystoryapp.data.Resource
import com.id.masel.mystoryapp.data.model.StoryResponse
import com.id.masel.mystoryapp.databinding.ActivityMapsBinding
import com.id.masel.mystoryapp.utility.Constanta.EXTRA_TOKEN
import com.id.masel.mystoryapp.utility.ViewModelFactory
import com.id.masel.mystoryapp.utility.ViewStateCallback
import com.id.masel.mystoryapp.utility.getAddressName

class MapsActivity : AppCompatActivity(), OnMapReadyCallback, ViewStateCallback<StoryResponse> {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val mapsViewModel: MapsViewModel by viewModels { factory }
    private var token: String? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val boundsBuilder = LatLngBounds.Builder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        token = intent.getStringExtra(EXTRA_TOKEN)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        supportActionBar?.apply {
            setDisplayUseLogoEnabled(true)
            elevation = 0f
        }

        token?.let {
            observeStories(it)
        }
    }

    private fun observeStories(token: String) {
        mapsViewModel.getStoriesLocation(token).observe(this) { result ->
            when (result) {
                is Resource.Success -> result.data?.let { onSuccess(it) }
                is Resource.Loading -> onLoading()
                is Resource.Error -> onError(result.message)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return super.onSupportNavigateUp()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.uiSettings.apply {
            isIndoorLevelPickerEnabled = true
            isZoomControlsEnabled = true
            isMapToolbarEnabled = true
            isCompassEnabled = true
        }

        getDeviceLocation()
        setupMapStyle()
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            getDeviceLocation()
        }
    }

    private fun getDeviceLocation() {
        if (ContextCompat.checkSelfPermission(this.applicationContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.isMyLocationEnabled = true
            fusedLocationClient.lastLocation.addOnSuccessListener {
                if (it != null) {
                    mapsViewModel.coordinateTemp.postValue(LatLng(it.latitude, it.longitude))
                } else {
                    mapsViewModel.coordinateTemp.postValue(LatLng(37.563936, -116.85123))
                }
            }
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun setupMapStyle() {
        try {
            val success = mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style))
            if (!success) {
                Log.e(TAG, "Style parsing failed.")
            }
        } catch (e: Resources.NotFoundException) {
            Log.e(TAG, "Can't find style. Error: ", e)
        }
    }

    override fun onSuccess(data: StoryResponse) {
        val list = data.listStory
        list.forEach { story ->
            Log.d("MapsActivity", "Adding marker: ${story.lat}, ${story.lon}, ${story.name}, ${story.description}")
            if (story.lat != null && story.lon != null) {
                addStoryMarker(story.lat, story.lon, story.name, story.description)
            }
        }
        val bounds = boundsBuilder.build()
        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
    }

    override fun onLoading() {
        Log.e(TAG, "OnLoading Map")
    }

    override fun onError(error: String?) {
        Log.e(TAG, "OnError Map: $error")
    }

    private fun addStoryMarker(lat: Double, lon: Double, name: String, description: String) {
        val latLng = LatLng(lat, lon)
        val addressName = getAddressName(this, lat, lon)
        mMap.addMarker(
            MarkerOptions()
                .position(latLng)
                .title("by $name : $description")
                .snippet(addressName)
        )
        boundsBuilder.include(latLng)
    }
}
