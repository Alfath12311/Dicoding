package com.id.masel.mystoryapp.activity.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.id.masel.mystoryapp.data.Repository
import com.id.masel.mystoryapp.data.Resource
import com.id.masel.mystoryapp.data.model.LoginResponse

class LoginViewModel(private val repository: Repository) : ViewModel() {
    fun userLogin(
        email: String,
        password: String
    ): LiveData<Resource<LoginResponse>> =
        repository.userLogin(email, password)
}