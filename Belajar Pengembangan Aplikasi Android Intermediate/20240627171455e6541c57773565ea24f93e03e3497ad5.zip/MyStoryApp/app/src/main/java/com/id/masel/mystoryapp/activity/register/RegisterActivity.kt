@file:Suppress("DEPRECATION")

package com.id.masel.mystoryapp.activity.register

import android.animation.ObjectAnimator
import android.app.ProgressDialog
import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import com.id.masel.mystoryapp.R
import com.id.masel.mystoryapp.data.Resource
import com.id.masel.mystoryapp.data.model.RegisterResponse
import com.id.masel.mystoryapp.databinding.ActivityRegisterBinding
import com.id.masel.mystoryapp.utility.Constanta.EXTRA_TOKEN
import com.id.masel.mystoryapp.utility.ViewModelFactory
import com.id.masel.mystoryapp.utility.ViewStateCallback
import com.id.masel.mystoryapp.activity.MainActivity
import com.id.masel.mystoryapp.activity.login.LoginActivity

@Suppress("DEPRECATION")
class RegisterActivity : AppCompatActivity(), ViewStateCallback<RegisterResponse?> {

    private lateinit var registerBinding: ActivityRegisterBinding
    private var name: Editable? = null
    private var email: Editable? = null
    private var pass: Editable? = null

    private val factory: ViewModelFactory = ViewModelFactory.getInstance(this)
    private val registerViewModel: RegisterViewModel by viewModels {
        factory
    }
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerBinding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(registerBinding.root)

        setupView()
        setMyButtonEnable()

        ObjectAnimator.ofFloat(registerBinding.imgRegister, View.TRANSLATION_X, 0f, 50f).apply {
            duration = 1500
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        registerBinding.btnLogin.setOnClickListener {
            val optionsCompat =
                ActivityOptionsCompat.makeSceneTransitionAnimation(
                    this,
                    Pair(registerBinding.btnRegist, "submit"),
                    Pair(registerBinding.btnLogin, "login"),
                    Pair(registerBinding.tfEmailRegist, "email"),
                    Pair(registerBinding.tfPassRegist, "password"),
                    Pair(registerBinding.tvRegister, "register"),
                )

            val view = registerBinding.root
            val intent = Intent(this, LoginActivity::class.java)
            view.animate()
                .alpha(0f)
                .setDuration(5000)
                .withEndAction { supportFinishAfterTransition() }
                .start()

            startActivity(intent, optionsCompat.toBundle())
        }

        registerBinding.etNameRegist.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (p0.toString().isNotEmpty()) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (p0.toString().isNotEmpty()) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

            override fun afterTextChanged(p0: Editable?) {
                if (p0.toString().isNotEmpty()) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

        })

        registerBinding.etPassRegist.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val s = p0.toString()

                if (s.length >= 8) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val s = p0.toString()

                if (s.length >= 8) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

            override fun afterTextChanged(p0: Editable?) {
                val s = p0.toString()

                if (s.length >= 8) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false

            }

        })

        registerBinding.etEmailRegist.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val s = p0.toString()

                if (Patterns.EMAIL_ADDRESS.matcher(s).matches()) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val s = p0.toString()

                if (Patterns.EMAIL_ADDRESS.matcher(s).matches()) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

            override fun afterTextChanged(p0: Editable?) {
                val s = p0.toString()

                if (Patterns.EMAIL_ADDRESS.matcher(s).matches()) setMyButtonEnable() else registerBinding.btnRegist.isEnabled = false
            }

        })

    }

    private fun setupView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setMyButtonEnable() {
        name = registerBinding.etNameRegist.text
        email = registerBinding.etEmailRegist.text
        pass = registerBinding.etPassRegist.text
        registerBinding.btnRegist.isEnabled = name != null && name.toString().isNotEmpty() && pass != null && pass.toString().isNotEmpty() && email != null && email.toString().isNotEmpty()
        registerBinding.btnRegist.setOnClickListener {
            registerViewModel.userRegister(
                name = name.toString(), email = email.toString(), password = pass.toString()
            ).observe(this@RegisterActivity) {
                if (it != null) {
                    when(it) {
                        is Resource.Success -> onSuccess(it.data)
                        is Resource.Loading -> onLoading()
                        is Resource.Error -> onError(it.message)
                    }
                }
            }
        }
    }

    override fun onSuccess(data: RegisterResponse?) {
        email = registerBinding.etEmailRegist.text
        pass = registerBinding.etPassRegist.text
        Log.e(TAG, "onSuccess register: $data")

        // Panggil userLogin dari ViewModel
        registerViewModel.userLogin(email.toString(), pass.toString())
            .observe(this@RegisterActivity) { result ->
                Log.e(TAG, "register login: $email, $pass")
                when (result) {
                    is Resource.Success -> {
                        val loginResult = result.data?.loginResult
                        Log.e(TAG, "onSuccess: ${loginResult?.token}")

                        Toast.makeText(
                            this,
                            "${getString(R.string.welcome)} $name!",
                            Toast.LENGTH_SHORT
                        ).show()

                        val intent = Intent(this@RegisterActivity, MainActivity::class.java)
                        intent.putExtra(EXTRA_TOKEN, loginResult?.token)
                        startActivity(intent)
                        finish()
                    }

                    is Resource.Error -> {
                        val errorMessage = result.message ?: getString(R.string.manually_login)
                        Log.e(TAG, "onFailure login register: $errorMessage")

                        Toast.makeText(this, getString(R.string.manually_login), Toast.LENGTH_SHORT)
                            .show()

                        startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
                        finish()
                    }

                    is Resource.Loading -> {

                    }
                }
            }
    }

    override fun onLoading() {
        Log.e(TAG, "onLoading register")
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please Wait")
        progressDialog.setMessage("Loading ...")
        progressDialog.setCancelable(false)
        progressDialog.show()
    }

    override fun onError(error: String?) {
        progressDialog.dismiss()
        Log.e(TAG, "onFailure register: $error")
        Toast.makeText(this, getString(R.string.manually_login), Toast.LENGTH_SHORT)
            .show()

        startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
        finish()
    }
}
