package com.id.masel.mystoryapp.activity.maps

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.google.android.gms.maps.model.LatLng
import com.id.masel.mystoryapp.data.Repository
import com.id.masel.mystoryapp.data.Resource
import com.id.masel.mystoryapp.data.local.StoryEntity
import com.id.masel.mystoryapp.data.model.StoryResponse

class MapsViewModel(private val repository: Repository): ViewModel() {
    val coordinateTemp = MutableLiveData(LatLng(37.563936, -116.85123))

    fun getStoriesLocation(token: String): LiveData<Resource<StoryResponse>> =
        repository.getStoriesLocation(token)

    fun getStories(token: String): LiveData<PagingData<StoryEntity>> =
        repository.getStory(token).cachedIn(viewModelScope)
}