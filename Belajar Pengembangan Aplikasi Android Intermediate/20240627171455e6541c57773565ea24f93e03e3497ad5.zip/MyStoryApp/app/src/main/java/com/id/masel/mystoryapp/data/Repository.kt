package com.id.masel.mystoryapp.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.liveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.id.masel.mystoryapp.UserPreference
import com.id.masel.mystoryapp.data.local.StoryDatabase
import com.id.masel.mystoryapp.data.local.StoryEntity
import com.id.masel.mystoryapp.data.model.LoginResponse
import com.id.masel.mystoryapp.data.model.RegisterResponse
import com.id.masel.mystoryapp.data.model.StoryResponse
import com.id.masel.mystoryapp.data.model.UploadResponse
import com.id.masel.mystoryapp.data.remote.ApiConfig
import com.id.masel.mystoryapp.data.remote.ApiService
import okhttp3.MultipartBody
import okhttp3.RequestBody

class Repository (private val preference: UserPreference, private val database: StoryDatabase) {
    private val retrofit: ApiService = ApiConfig.getApiService()

    fun userLogin(email: String, password: String): LiveData<Resource<LoginResponse>> = liveData{
        try {
            emit(Resource.Loading())
            val response = retrofit.loginUser(email, password)
            val token = response.loginResult.token
            preference.saveUser(token)
            emit(Resource.Success(response))
        } catch (e: Exception) {
            e.printStackTrace()
            emit(Resource.Error(e.toString()))
        }
    }

    fun userRegister(name: String, email: String, password: String): LiveData<Resource<RegisterResponse>> = liveData {
        try {
            emit(Resource.Loading())
            val response = retrofit.registerUser(name = name, email = email, password = password)
            emit(Resource.Success(response))
        } catch (e: Exception) {
            e.printStackTrace()
            emit(Resource.Error(e.toString()))
        }
    }

    fun getStory(token: String): LiveData<PagingData<StoryEntity>> {
        val tokenId = getToken(token)
        @OptIn(ExperimentalPagingApi::class)
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            remoteMediator = StoryRemoteMediator(
                database,
                retrofit,
                tokenId
            ),
            pagingSourceFactory = {
                database.storyDao().getAllStory()
            }
        ).liveData
    }

    fun getStoriesLocation(token: String): LiveData<Resource<StoryResponse>> = liveData {
        try {
            emit(Resource.Loading())
            val getToken = getToken(token)
            val response = retrofit.getStoriesWithLocation(token = getToken, location = 1)
            emit(Resource.Success(response))
        } catch (e: Exception) {
            e.printStackTrace()
            emit(Resource.Error(e.toString()))
        }
    }

    fun uploadStory(
        token: String,
        description: RequestBody,
        image: MultipartBody.Part,
        lat: RequestBody? = null,
        lon: RequestBody? = null
    ): LiveData<Resource<UploadResponse>> = liveData {
        val tokenId = getToken(token)
        try {
            emit(Resource.Loading())
            val response = retrofit.addStory(tokenId, image, description, lat, lon)
            emit(Resource.Success(response))
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("UPLOAD", e.toString())
            emit(Resource.Error(e.toString()))
        }
    }

    fun getUser(): LiveData<String?> = preference.getUser().asLiveData()

    suspend fun logout() = preference.logout()

    private fun getToken(token: String): String = "Bearer $token"
}
