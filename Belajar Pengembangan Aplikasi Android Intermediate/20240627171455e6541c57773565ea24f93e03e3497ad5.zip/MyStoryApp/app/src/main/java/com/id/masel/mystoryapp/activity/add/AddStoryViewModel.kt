package com.id.masel.mystoryapp.activity.add

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.id.masel.mystoryapp.data.Repository
import com.id.masel.mystoryapp.data.Resource
import com.id.masel.mystoryapp.data.model.UploadResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody

class AddStoryViewModel(private val repository: Repository): ViewModel() {
    fun getUser(): LiveData<String?> = repository.getUser()

    fun addStory(
        token: String,
        image: MultipartBody.Part,
        description: RequestBody,
        lat: RequestBody? = null,
        lon: RequestBody? = null)
    : LiveData<Resource<UploadResponse>> =
        repository.uploadStory(token, description, image, lat, lon)
}