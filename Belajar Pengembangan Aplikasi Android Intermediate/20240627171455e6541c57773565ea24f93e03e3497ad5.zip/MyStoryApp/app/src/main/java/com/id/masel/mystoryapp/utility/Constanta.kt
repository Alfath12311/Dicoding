package com.id.masel.mystoryapp.utility

object Constanta {
    const val EXTRA_TOKEN = "extra_token"
    const val EXTRA_STORY = "extra_story"
    const val TIME_SPLASH = 1500L
}