package com.id.masel.mystoryapp.activity

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.id.masel.mystoryapp.data.Repository
import com.id.masel.mystoryapp.data.local.StoryEntity

class MainViewModel(private val repository: Repository): ViewModel() {
    suspend fun logout() = repository.logout()

    fun getStories(token: String): LiveData<PagingData<StoryEntity>> =
        repository.getStory(token).cachedIn(viewModelScope)
}